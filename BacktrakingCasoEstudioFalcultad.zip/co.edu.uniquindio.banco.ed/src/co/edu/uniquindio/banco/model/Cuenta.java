package co.edu.uniquindio.banco.model;

import java.io.Serializable;
import java.util.ArrayList;

import co.edu.uniquindio.banco.model.services.ICuentaService;

public class Cuenta implements ICuentaService , Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String numeroCuenta;
	private Double saldo;
	ArrayList<Transaccion> listaTransacciones = new ArrayList<Transaccion>();
	
	public Cuenta() {
		// TODO Auto-generated constructor stub
	}

	
	
	@Override
	public void retirarDinero(Double cantidad) {
		// TODO Auto-generated method stub
		
	}
	
	
	public void crearTransaccion() {
		
	}
	
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}
	
	
	

	public ArrayList<Transaccion> getListaTransacciones() {
		return listaTransacciones;
	}

	public void setListaTransacciones(ArrayList<Transaccion> listaTransacciones) {
		this.listaTransacciones = listaTransacciones;
	}


	
}
