package co.edu.uniquindio.banco.model;

import java.io.Serializable;

public class CuentaCorriente extends Cuenta implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CuentaCorriente() {
		// TODO Auto-generated constructor stub
	}

}
