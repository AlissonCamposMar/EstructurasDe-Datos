package co.edu.uniquindio.banco.model;
import java.io.Serializable;

public class Cliente extends Persona implements Serializable, Comparable<Cliente>{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Cliente() {
		
	}

	@Override
	public int compareTo(Cliente c) {
		return this.getNombre().compareToIgnoreCase(c.getNombre());
	}

}
