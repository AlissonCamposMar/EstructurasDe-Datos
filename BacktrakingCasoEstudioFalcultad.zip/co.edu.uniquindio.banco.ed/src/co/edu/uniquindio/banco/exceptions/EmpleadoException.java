package co.edu.uniquindio.banco.exceptions;

public class EmpleadoException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public EmpleadoException(String mensaje) {
		super(mensaje);
	}

}
