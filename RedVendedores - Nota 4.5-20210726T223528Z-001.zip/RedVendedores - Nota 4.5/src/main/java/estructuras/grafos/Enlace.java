package estructuras.grafos;
/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class Enlace {
/*
 * Atributos
 */
	private Nodo nodo;
	private double peso;
	/*
	 * Metodo contructor.
	 */
	public Enlace(Nodo nodo, double tiempo) {
		super();
		this.nodo = nodo;
		this.peso = tiempo;
	}

	/*
	 * Metodos get and set de la clase 
	 */
	public Nodo getNodo() {
		return nodo;
	}

	public void setNodo(Nodo nodo) {
		this.nodo = nodo;
	}

	public double getTiempo() {
		return peso;
	}

	public void setTiempo(double tiempo) {
		this.peso = tiempo;
	}
	
	
	
	
}
