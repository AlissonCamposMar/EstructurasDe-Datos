package estructuras.grafos;

import java.util.ArrayList;

import model.Vendedor;

/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class Nodo {
    /*
     * Atributos 
     */
	private Vendedor vendedor;
	private String nombre;
	private ArrayList<Enlace> enlaces; // Nodo siguiente;
	private boolean flag;
 /*
  * Metodos contructor 
  */
	public Nodo(String nombre) {

		this.nombre = nombre;
		enlaces = new ArrayList<Enlace>();
		this.flag = false;
		enlaces.add(null);
	}

	public Nodo(String nombre, Vendedor vendedor) {

		this.vendedor = vendedor;
		this.nombre = nombre;
		enlaces = new ArrayList<Enlace>();
		enlaces.add(null);
	}
	
/*
 * Metodo que permite retornar el numero de enlaces de un nodo 
 */
	public int getSize() {
		return enlaces.size();
	}
      /*
       *@Param  Nodo destino
       * metodo que permite conectar el nodo dado como parametro el nodoDestino
       */
	
	public void conectarNoDirigido (Nodo nodoDestino) {
		int i;
		for(i=0;i<enlaces.size();i++) {
			if(enlaces.get(i)==null) {
				break;
			}
		}
		conectar(nodoDestino, i);
	}
	
	/*
     * @Param Nodo  destino, double peso
     * Metodo que permite conectar un  nodo ingresando como parameto el nodoDestino y su peso .
     */
	
	public void conectarNoDirigido(Nodo destino, double peso) {
		int i;
		for(i=0;i<enlaces.size();i++) {
			if(enlaces.get(i)==null) {
				break;
			}
		}
		conectar(destino, i, peso);
	}
	
	/*
     * @Param Nodo  destino,int indice, 
     * Metodo que permite conectar un  nodo ingresando como parameto el nodoDestino , el indice.
     */
	
	
	public void conectar(Nodo destino, int indice) {
		// si la posicion indice existe en el vector de enlaces

		if (indice < enlaces.size()) {
			enlaces.set(indice, new Enlace(destino, 1.0));
		} else {
			int n = indice - enlaces.size();

			// la lista de enlaces crece. En las posiciones intermedias
			// se asigna null
			for (int i = 0; i < n; i++) {
				enlaces.add(null);
			}

			// en la posici�n indice del vector enlaces se almacena
			// una referencia al nodo destino
			enlaces.add(new Enlace(destino, 1.0));
		}
	}
    /*
     * @Param Nodo  destino,int indice, double peso
     * Metodo que permite conectar un  nodo ingresando como parameto el nodoDestino , el indice y  su peso .
     */
	public void conectar(Nodo destino, int indice, double peso) {
		// si la posicion indice existe en el vector de enlaces

		if (indice < enlaces.size()) {
			enlaces.set(indice, new Enlace(destino, peso));
		} else {
			int n = indice - enlaces.size();

			// la lista de enlaces crece. En las posiciones intermedias
			// se asigna null
			for (int i = 0; i < n; i++) {
				enlaces.add(null);
			}

			// en la posici�n indice del vector enlaces se almacena
			// una referencia al nodo destino
			enlaces.add(new Enlace(destino, peso));
		}
	}
	
	
	
	
   /*
    * @Param int indice 
    * metodo que permite desconectar un nodo de otro
    */
	public void desconectar(int indice) {
		enlaces.set(indice, null);
	}
    /*
     * metodo que permite Verificar si dos nodos estan conectados. 
     */
	public boolean estaConectado(int indice) {
		if (enlaces.get(indice) != null) {
			return true;
		} else {

			return false;

		}
	}
   /*
    * @Param Nodo nodo
    * Metodo que retorna el indice del enlace ingresando como parametro el nodo .
    */
	public int obtenerIndiceDelEnlace(Nodo nodo) {
		for (int i = 0; i < enlaces.size(); i++) {
			if (enlaces.get(i) != null && enlaces.get(i).getNodo().equals(nodo)) {
				return i;
			}

		}
		return -1;
	}
     /*
      * @Param Nodo nodo 
      * metodo que permite verificar  con cual otro vertice esta conectado el nodo ingresado .
      */
	public boolean estaConectadoCon(Nodo nodo) {
		for (int i = 0; i < enlaces.size(); i++) {
			if (enlaces.get(i) != null && enlaces.get(i).getNodo().equals(nodo)) {
				return true;
			}

		}
		return false;
	}
       
	public Nodo siguienteNodo() { // seguirEnlace
		return enlaces.get(0).getNodo();
	}
   /*
    * @Param indice 
    * Metodo que permite obtener el nodo , ingresando como parametro el  indice del nodo .
    */
	public Nodo getNodo(int indice) {
		if (indice < enlaces.size()) {
			if (enlaces.get(indice) != null) {
				return enlaces.get(indice).getNodo();
			}
		}
		return null;
	}

	public Enlace getEnlace(int indice) {
		if (indice < enlaces.size()) {
			if (enlaces.get(indice) != null) {
				return enlaces.get(indice);
			}
		}
		return null;
	}

	
	
	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public String getNombre() {
		return nombre;
	}
  /*
   * permite imprimir el nodo de manera ordenada 
   */
	@Override
	public String toString() {
		String s = "\n\n\t\tTarea " + nombre + ":  \n\t\t";
		s += "Id: {" + vendedor + "}\n\t\t";
		s += "Total enlaces: " + enlaces.size() + "\n\t\t";

		for (int i = 0; i < enlaces.size(); i++) {
			s += "[" + i + "] Enlazado con la tarea ";
			if (enlaces.get(i) != null) {

				s += enlaces.get(i).getNodo().getNombre() + " , tiempo de espera: " + enlaces.get(i).getTiempo()
						+ " minutos \n\t\t";
			} else {
				s += null + "\n\t\t";
			}
		}
		s += "\n\t\t";
		return s;

	}
	/*
	 * @Param boolean valor
	 * Metodos get and set de flag 
	 */

	public void setFlag(boolean valor) {
		flag = valor;
	}

	public boolean getFlag() {
		return flag;
	}
	
	

}
