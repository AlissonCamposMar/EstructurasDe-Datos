package estructuras.grafos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import estructuras.ListaEnlazada;
import exceptions.ErrorExisteNodo;
import exceptions.ErrorNodoNoExiste;
import exceptions.ErrorNodosConectados;
import exceptions.ErrorNodosNoConectados;
import model.Vendedor;

/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class GrafoNoDirigido {
	/*
	 * Atributos
	 */
	private HashMap<String, Nodo> grafo;
	private int size;
	private Nodo inicial;

	/*
	 * Metodo constructor
	 */
	public GrafoNoDirigido() {
		grafo = new HashMap<String, Nodo>();
		size = 0;
		inicial = null;
	}

	/*
	 * @Param String Nombre, String elemento Metodo que permite agregar un nuevo
	 * nodo al grafo por medio del nombre , validando por medio del nombre que el
	 * grafo no exista, incrementa el tama�o del grafo de tipo Hashmap.
	 */
	public void agregar(String nombre, Vendedor elemento) throws ErrorExisteNodo {
		if (!grafo.containsKey(nombre)) {
			Nodo nodo = new Nodo(nombre, elemento);
			grafo.put(nombre, nodo);
			size++;
		} else {
			throw new ErrorExisteNodo("Ya existe nodo con ese nombre " + nombre);
		}

	}
	/*
	 * @Param String nombre Metodo que permite remover un nodo del grafo ,
	 * ingresando el nombre del nodo por parametro.
	 */

	public void eliminar(String nombre) {
		if (grafo.containsKey(nombre)) {
			grafo.remove(nombre);
			size--;
		}
	}
	/*
	 * @Param String nombreOrigen,String nombreDestino, Metodo que permite conectar
	 * nodos , por medio del nodo inicial , nodo final, valida que el nombre de los
	 * dos nodos existan en el grafo.
	 */

	public void conectar(String nombreOrigen, String nombreDestino) throws ErrorNodoNoExiste {
		Nodo nodoOrigen;
		Nodo nodoDestino;
		if (grafo.containsKey(nombreOrigen)) {
			nodoOrigen = grafo.get(nombreOrigen);
			if (grafo.containsKey(nombreDestino)) {
				nodoDestino = grafo.get(nombreDestino);
			} else {
				throw new ErrorNodoNoExiste("El nodo destino no existe");
			}
			nodoOrigen.conectarNoDirigido(nodoDestino);
			if (nodoOrigen != nodoDestino) {
				nodoDestino.conectarNoDirigido(nodoOrigen);
			}

		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
	}

	/*
	 * @Param String nombre Origen,String nombreDestino ,int peso Metodo que permite
	 * conectar nodos conociendo el nodo inicial , el nodo final , y el peso del
	 * enlace. Valida que los nodos existan.
	 */
	public void conectar(String nombreOrigen, String nombreDestino, int peso)
			throws ErrorNodoNoExiste, ErrorExisteNodo, ErrorNodosConectados {
		Nodo nodoOrigen;
		Nodo nodoDestino;
		if (grafo.containsKey(nombreOrigen)) {
			nodoOrigen = grafo.get(nombreOrigen);
			if (grafo.containsKey(nombreDestino)) {
				nodoDestino = grafo.get(nombreDestino);
			} else {
				throw new ErrorNodoNoExiste("El nodo destino no existe");
			}
			if (nodoOrigen.estaConectadoCon(nodoDestino)) {
				throw new ErrorNodosConectados("Ya han sido conectados previamente");
			}

			nodoOrigen.conectarNoDirigido(nodoDestino, peso);
			if (nodoOrigen != nodoDestino) {
				nodoDestino.conectarNoDirigido(nodoOrigen, peso);
			}
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
	}
	/*
	 * @Param String nombre,int indice Metodo que permite desconecar nodos, entrando
	 * como parametros el nombre y el indice del nodo origen valida que el nodo que
	 * se desea desconectar exista.
	 */

	public void desconectar(String nombre, int indice) throws ErrorNodoNoExiste {
		Nodo nodoOrigen;
		if (grafo.containsKey(nombre)) {
			nodoOrigen = grafo.get(nombre);
			Nodo b = nodoOrigen.getNodo(indice);
			if (b != null) {
				int aux = b.obtenerIndiceDelEnlace(nodoOrigen);
				b.desconectar(aux);
			}
			nodoOrigen.desconectar(indice);
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");

		}
	}

	/*
	 * @Param Strig nombreOrigen,String nombreDestino metodo que permite desconectar
	 * dos nodos entrando como parametros el nombre del nodo origen y el nodo
	 * destino valida que el nodo origen exista en el grafo para desconectarlo del
	 * otro nodo.
	 */
	public void desconectar(String nombreOrigen, String nombreDestino)
			throws ErrorNodoNoExiste, ErrorNodosNoConectados {

		Nodo nodoOrigen = buscarNodo(nombreOrigen);
		Nodo nodoDestino = buscarNodo(nombreDestino);
		int indice = nodoOrigen.obtenerIndiceDelEnlace(nodoDestino);
		int indice2 = nodoDestino.obtenerIndiceDelEnlace(nodoOrigen);
		if (indice != -1) {
			nodoOrigen.desconectar(indice);
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");

		}
		if (indice2 != -1) {
			nodoDestino.desconectar(indice2);
		} else {
			throw new ErrorNodoNoExiste("Nodo destino no existe");

		}
	}

	/*
	 * @Param String nombre, int indice
	 * 
	 * @Return boolean respuesta Metodo que permite verificar que los nodos esten
	 * conectados, entran como parametros el nombre del nodo y el indice . valida si
	 * el nodo origen existe.
	 */
	public boolean estaConectado(String nombre, int indice) throws ErrorNodoNoExiste {

		boolean respuesta = false;
		Nodo nodoOrigen;

		if (grafo.containsKey(nombre)) {
			nodoOrigen = grafo.get(nombre);
			respuesta = nodoOrigen.estaConectado(indice);
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
		return respuesta;
	}

	/*
	 * @Param String nombre,int indice
	 * 
	 * @Return nodoEnlace Metodo que retorna el enlace siguiente del nodoOrigen
	 */
	public Nodo seguirEnlace(String nombre, int indice) throws ErrorNodoNoExiste {
		Nodo nodoOrigen = null;
		Nodo nodoEnlace = null;
		if (grafo.containsKey(nombre)) {
			nodoOrigen = grafo.get(nombre);
			nodoEnlace = nodoOrigen.siguienteNodo(); // siguiente enlace
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
		return nodoEnlace;
	}

	/*
	 * @Param String Nombre metodo que permite modificar el nodo inicil entrando
	 * como parametro el nombre del nodo. valida si el nodoOrigen existe
	 */

	public void setInicial(String nombre) throws ErrorNodoNoExiste {
		Nodo nodo = null;
		if (grafo.containsKey(nombre)) {
			nodo = grafo.get(nombre);
			inicial = nodo;
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
	}

	/*
	 * @Param String nombre ,int elemento Metodo que permite modificar el dato de un
	 * nodo. valida si el nodo existe .
	 */
	public void setDato(String nombre, Vendedor elemento) throws ErrorNodoNoExiste {
		Nodo nodo = null;
		if (grafo.containsKey(nombre)) {
			nodo = grafo.get(nombre);
			nodo.setVendedor(elemento);
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}

	}
	/*
	 * @Param String nombre
	 * 
	 * @Return dato Metodo que permite obtener el dato de un nodo entrando como
	 * parametro el nombre del nodo.
	 */

	public Vendedor getDato(String nombre) throws ErrorNodoNoExiste {
		Vendedor dato;
		Nodo nodo;
		if (grafo.containsKey(nombre)) {
			nodo = grafo.get(nombre);
			dato = nodo.getVendedor();
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}

		return dato;
	}

	/*
	 * @Return size. Metodo que permite obtener la longitud de un grafo.
	 */
	public int getSize() {
		return size;
	}

	/*
	 * @Param String nombre
	 * 
	 * @Return int dato Metodo que permite obtener la longitud de un Nodo ingresando
	 * como parametro el nombre de este.
	 */
	public int getSizeNodo(String nombre) throws ErrorNodoNoExiste {
		int dato;
		Nodo nodo;
		if (grafo.containsKey(nombre)) {
			nodo = grafo.get(nombre);
			dato = nodo.getSize();
			return dato;
		} else {
			throw new ErrorNodoNoExiste("Nodo origen no existe");
		}
	}

	/*
	 * Metodo que permite modificar la longitud de un grafo.
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/*
	 * Metodo que permite obtener el nodo inicial de un grafo.
	 */
	public Nodo getInicial() {
		return inicial;
	}

	/*
	 * @Return S Metodo que permite imprimir el grafo .
	 */
	@Override
	public String toString() {

		String s = "Grafo No Dirigido: \n\n";
		s += "Cantidad de nodos (Tareas): " + getSize() + "\n";
		s += "Nodo Inicial: " + inicial.getNombre() + "\n\n\t\t";
		s += grafo + "\n\t\t";

		return s;
//	
//	}
	}

	/*
	 * @Param String Tarea
	 * 
	 * @Return contador. Metodo que permite retornar el numero de enlaces de entrada
	 * de un nodo,ingresando como parametro el nodo.
	 */
	public int calcularGradoEntrada(String tarea) {
		Nodo nodo = buscarNodo(tarea);
		int contador = 0;
		for (Nodo n : grafo.values()) {
			if (n.estaConectadoCon(nodo)) {
				contador++;
			}
		}
		return contador;
	}
	/*
	 * @Return grado Metodo que permite retornar el numero de enlaces de un nodo .
	 */

	public int determinarGradoGrafo() {
		int grado = 0;
		for (Nodo n : grafo.values()) {
			if (n.getSize() > grado) {
				grado = n.getSize();
			}
		}

		return grado;

	}
	/*
	 * @Param
	 * 
	 * @Return Metodo que permite retornar un subgrafo con los nodos conectados al
	 * vertice dado.
	 */

	public GrafoNoDirigido retornarSubGrafo(String tarea)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {
		GrafoNoDirigido subGrafo = new GrafoNoDirigido();
		Nodo vertice = buscarNodo(tarea);

		subGrafo.agregar(vertice.getNombre(), vertice.getVendedor());
		for (int i = 0; i < vertice.getSize(); i++) {
			Enlace aux = vertice.getEnlace(i);
			if (aux != null && aux.getNodo() != null) {
				try {
					subGrafo.agregar(aux.getNodo().getNombre(), aux.getNodo().getVendedor());
				} catch (ErrorExisteNodo e) {
				}
				subGrafo.conectar(tarea, aux.getNodo().getNombre(), (int) aux.getTiempo());
			}
		}
		subGrafo.setInicial(tarea);
		return subGrafo;
	}

	/*
	 * @Param String nombreOrigen , String NombreDestino Metodo que permite dado el
	 * nombre de dos nodos retorne si los dos vertices estan conectados
	 */
	public boolean estaConectado(String nombreOrigen, String nombreDestino) throws ErrorNodoNoExiste {
		Nodo nodoOrigen = buscarNodo(nombreOrigen);
		Nodo nodoDestino = buscarNodo(nombreDestino);

		return nodoOrigen.estaConectadoCon(nodoDestino);
	}

	/*
	 * @Param String tarea
	 * 
	 * @Return precedentes Metodo que permite retornar la lista con los vertices que
	 * preceden al nodo ingresado como parametro.
	 */
	public List<String> retornarVerticesPrecedentes(String tarea) {
		List<String> precedentes = new ArrayList<String>();
		Nodo nodo = buscarNodo(tarea);
		for (Nodo n : grafo.values()) {
			if (n.estaConectadoCon(nodo)) {
				precedentes.add(n.getNombre());
			}
		}
		return precedentes;

	}

	/*
	 * @Return matrizAdyacencias Metodo que permite crear la matriz de adyacencias
	 * del grafo.
	 */
	public String[][] crearMatrizAdyacencia() {

		String[][] adyacencia = new String[size + 1][size + 1];
		int i = 1;
		for (Nodo n : grafo.values()) {
			adyacencia[i][0] = n.getNombre();
			adyacencia[0][i] = n.getNombre();
			i++;
		}
		adyacencia[0][0] = "";
		for (i = 1; i <= size; i++) {
			Nodo origen = buscarNodo(adyacencia[0][i]);
			for (int j = 1; j <= size; j++) {

				Nodo destino = buscarNodo(adyacencia[0][j]);
				int indiceEnlace = origen.obtenerIndiceDelEnlace(destino);
				if (indiceEnlace != -1) {
					adyacencia[i][j] = "" + origen.getEnlace(indiceEnlace).getTiempo();
				} else {
					adyacencia[i][j] = "";
				}
			}
		}

		return adyacencia;
	}

	public ListaEnlazada<Vendedor> getDatos() {
		ListaEnlazada<Vendedor> vendedores = new ListaEnlazada<Vendedor>();
		for (Nodo nodo : grafo.values()) { // metodo values del HashMap sirve para retornar valores (vendedores), sin
											// las llaves (keys)
			vendedores.agregar(nodo.getVendedor());
		}
		return vendedores;
	}

	/*
	 * @Param String nombre Metodo que permite buscar un nodo en un grado dado el
	 * nommbre del nodo
	 */
	public Nodo buscarNodo(String nombre) {
		return grafo.get(nombre);
	}

}
