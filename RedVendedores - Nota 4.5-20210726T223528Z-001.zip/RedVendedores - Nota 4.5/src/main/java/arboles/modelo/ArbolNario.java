package arboles.modelo;

import estructuras.ListaEnlazada;

/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class ArbolNario<T extends Comparable<T>> {

	private Nodo<T> raiz;
	private Nodo<T> actual;
	private int maxHijos;

	/**
	 * M�todo constructor
	 * 
	 */
	public ArbolNario() {
		raiz = null;
		actual = null;
		maxHijos = 0;

	}

	/**
	 * M�todo que agrega nodo principal del �rbol
	 * 
	 * @param dato
	 */
	public void agregarRaiz(T dato) {
		Nodo<T> nuevo = new Nodo<T>(dato.toString(), dato);
		raiz = nuevo;
		actual = nuevo;

	}

	/**
	 * M�todo que agrega nodo hijo
	 * 
	 * @param dato
	 * @param indice
	 */
	public void agregarHijo(int indice, T dato) {
		Nodo<T> nuevo = new Nodo<T>(dato.toString(), dato);
		actual.conectar(nuevo, indice);
		nuevo.conectar(actual, 0);
		actual = nuevo;
	}

	public void agregarHijo(T dato) {
		Nodo<T> nuevo = new Nodo<T>(dato.toString(), dato);
		int indice = actual.buscarEnlaceLibre();
		actual.conectar(nuevo, indice);
		nuevo.conectar(actual, 0);
		actual = nuevo;

	}

	public void setDato(T dato) {
		actual.setDato(dato);
	}

	public boolean ActualEsHoja() {
		boolean esHoja = false;
		if (actual.getEnlaces().size() == 1) {
			esHoja = true;
		}
		return esHoja;
	}

	public T getDato() {
		return actual.getDato();
	}

	/**
	 * Metodo get que retorna el n�mero de hijos
	 */
	public int getNumeroHijos() {
		int numHijos = actual.getSize() - 1;
		return numHijos;
	}

	public boolean actualEsRaiz() {
		return actual == raiz;
	}

	public void irARaiz() {
		actual = raiz;
	}

	public void irAPadre() {

		if (actual != raiz) {
			actual = actual.seguirEnlace(0);
		}

	}

	public String irAlHijo(int indice) {
		String mensaje = "";
		if (actual.seguirEnlace(indice) == null) {
			mensaje = "No se encontro hijo en ese indice";
		} else {
			actual = actual.seguirEnlace(indice);
		}
		return mensaje;
	}

	/**
	 * Metodo encargado realizar un preorden del �rbol
	 * 
	 * @param lista
	 */
	public void preOrden(ListaEnlazada<T> lista) {
		preOrden(actual, lista);
	}

	protected void preOrden(Nodo<T> nodo, ListaEnlazada<T> lista) {
		int i;
		T dato;
		if (nodo != null) {
			dato = nodo.getDato();
			lista.agregar(dato);
			for (i = 1; i < nodo.getSize(); i++) {
				if (nodo.estaConectado(i)) {
					preOrden(nodo.seguirEnlace(i), lista);
				}
			}
		}
	}

	/**
	 * Metodo encargado realizar un pos-orden del �rbol
	 * 
	 * @param lista
	 */
	public void postOrden(ListaEnlazada<T> lista) {
		postOrden(actual, lista);
	}

	protected void postOrden(Nodo<T> nodo, ListaEnlazada<T> lista) {
		int i;
		T dato;
		if (nodo != null) {
			for (i = 1; i < nodo.getSize(); i++) {
				if (nodo.estaConectado(i)) {
					postOrden(nodo.seguirEnlace(i), lista);
				}
			}
			dato = nodo.getDato();
			lista.agregar(dato);
		}

	}

	public ArbolBinario<T> toArbolBinario() {

		ArbolBinario<T> arbolBinario = new ArbolBinario<T>();
		ListaEnlazada<T> lista = new ListaEnlazada<T>();
		irARaiz();
		preOrden(lista);
		for (T i : lista) {
			arbolBinario.agregarBinarioOrdenado(i);
		}
		return arbolBinario;

	}

	@Override
	public String toString() {
		return "ArbolNario [raiz=" + raiz + ", actual=" + actual + ", maxHijos=" + maxHijos + "]";
	}

}
