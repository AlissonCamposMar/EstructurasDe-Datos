package arboles.modelo;

import java.util.ArrayList;

/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class Nodo<T> {
	private T dato;
	private ArrayList<Enlace<T>> enlaces;
	private String nombre;
	private boolean flag;

	/**
	 * 
	 * M�todo constructor
	 * 
	 */

	public Nodo(String nombre) {
		this.nombre = nombre;

		enlaces = new ArrayList<Enlace<T>>();
		enlaces.add(null);
	}

	public Nodo(String nombre, T dato) {
		this.dato = dato;
		this.nombre = nombre;

		enlaces = new ArrayList<Enlace<T>>();
		enlaces.add(null);
	}

	/**
	 * M�todo set
	 * 
	 */
	public void setDato(T dato) {
		this.dato = dato;
	}

	/**
	 * M�todo get
	 * 
	 */
	
	public T getDato() {
		return dato;
	}

	public String getNombre() {
		return nombre;
	}

	public int getSize() {
		return enlaces.size();
	}

	/**
	 * Conecta los nodos, considerando el �ndice sin peso
	 * 
	 * @param destino
	 * @param indice
	 */
	
	public void conectar(Nodo<T> destino, int indice) {
		// si la posicion indice existe en el vector de enlaces
		if (indice < enlaces.size()) {
			enlaces.set(indice, new Enlace<T>(destino, 1.0));
		} else {
			int n = indice - enlaces.size();

			// la lista de enlaces crece. En las posiciones intermedias
			// se asigna null
			for (int i = 0; i < n; i++) {
				enlaces.add(null);
			}

			// en la posici�n indice del vector enlaces se almacena
			// una referencia al nodo destino
			enlaces.add(new Enlace<T>(destino, 1.0));
		}
	}

	/**
	 * Conecta los nodos, considerando el �ndice tambi�n el peso
	 * 
	 * @param destino
	 * @param indice
	 * @param peso
	 */
	
	public void conectar(Nodo<T> destino, int indice, double peso) {
		// si la posicion indice existe en el vector de enlaces
		if (indice < enlaces.size()) {
			enlaces.set(indice, new Enlace<T>(destino, peso));
		} else {
			int n = indice - enlaces.size();

			// la lista de enlaces crece. En las posiciones intermedias
			// se asigna null
			for (int i = 0; i < n; i++) {
				enlaces.add(null);
			}

			// en la posici�n indice del vector enlaces se almacena
			// una referencia al nodo destino
			enlaces.add(new Enlace<T>(destino, peso));
		}
	}
	
	/**
	 * Desconecta los dos nodos, por medio del indic
	 * 
	 * @param indice
	 */
		public void desconectar(int indice) {
		// la referencia especificada se reemplaza por null
		enlaces.set(indice, null);
	}

	/**
	 * Desconecta los dos nodos, por medio del nodo destino
	 * 
	 * @param nombreDestino
	 */
	public void desconectarDosNodos(String nombreDestino) {

		for (int i = 0; i < enlaces.size(); i++) {

			if (enlaces.get(i) != null) {
				if (enlaces.get(i).getNodo().getNombre() == nombreDestino) {
					enlaces.set(i, null);
					return;
				}
			}
		}
	}

	/**
	 * Verifica si dos nodos en especifico estan conectados, por medio de nodo
	 * destino
	 * 
	 * @param nombreDestino
	 * @return
	 */
	public boolean estaConectadoEspecifico(String nombreDestino) {
		boolean respuesta = false;
		for (int i = 0; i < enlaces.size() && !respuesta; i++) {

			if (enlaces.get(i) != null) {

				if (enlaces.get(i).getNodo().getNombre() == nombreDestino) {
					respuesta = true;
				}

			}
		}
		return respuesta;
	}

	/**
	 * Verifica si dos nodos en especifico estan conectados, por medio del indice
	 */
	public boolean estaConectado(int indice) {
		if (indice < enlaces.size() && enlaces.get(indice) != null) {
			return true;
		} else {
			return false;
		}
		}

	public Nodo<T> seguirEnlace(int indice) {
		if (indice < enlaces.size()) {
			return enlaces.get(indice).getNodo();
		}
		return null;
	}


	/**
	 * Genera el grado de salida del nodo actual @return, grado de salida
	 */
	public int contarGradosSalida() {
		return enlaces.size();
	}

	/**
	 * Muestra el subgrafo del nodo actual
	 * 
	 * @return
	 */
	public String mostrarSubGrafo() {
		String s = "nodo " + nombre + ": \n\t\t";
		s += "{" + dato + "}\n\t\t";
		s += "Enlaces: " + enlaces.size() + "\n\t\t";
		for (int i = 0; i < enlaces.size(); i++) {
			s += "[" + i + "]:";
			if (enlaces.get(i) != null) {
				s += enlaces.get(i).getNodo().getNombre() + " --- Peso: " + enlaces.get(i).getPeso() + "\n\t\t";
			} else {
				s += null + "\n\t\t";
			}
		}
		return s;
	}

	public void setFlag(boolean valor) {
		flag = valor;
	}

	public boolean getFlag() {
		return flag;
	}

	public ArrayList<Enlace<T>> getEnlaces() {
		return enlaces;
	}

	public String toString() {
		String s = "\n";
		s += "Nodo: " + nombre + "\n";
		s += "Enlaces: " + enlaces.size() + "\n\t\t";
		for (int i = 0; i < enlaces.size(); i++) {
			s += "[" + i + "]:";
			if (enlaces.get(i) != null) {
				s += enlaces.get(i).getNodo().getNombre() + " --- Peso: " + enlaces.get(i).getPeso() + "\n\t\t";
			} else {
				s += null + "\n\t\t";
			}
		}
		return s;
	}

	public int buscarEnlaceLibre() {
		for (int i = 1; i < enlaces.size(); i++) {
			if (enlaces.get(i) == null) {
				return i;
			}
		}
		return enlaces.size();
	}

}
