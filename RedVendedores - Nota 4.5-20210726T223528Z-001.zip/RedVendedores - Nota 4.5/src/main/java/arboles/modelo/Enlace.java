package arboles.modelo;
/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */
public class Enlace<T> {
	private Nodo<T> nodo;
	private double peso;

	public Enlace(Nodo<T> nodo, double peso) {
		super();
		this.nodo = nodo;
		this.peso = peso;
	}

	/**
	 * @return the nodo
	 */
	public Nodo<T> getNodo() {
		return nodo;
	}

	/**
	 * @param nodo the nodo to set
	 */
	public void setNodo(Nodo<T> nodo) {
		this.nodo = nodo;
	}

	/**
	 * @return the peso
	 */
	public double getPeso() {
		return peso;
	}

	/**
	 * @param peso the peso to set
	 */
	public void setPeso(double peso) {
		this.peso = peso;
	}

	@Override
	public String toString() {
		return "Enlace [nodo=" + nodo + ", peso=" + peso + "]";
	}

}
