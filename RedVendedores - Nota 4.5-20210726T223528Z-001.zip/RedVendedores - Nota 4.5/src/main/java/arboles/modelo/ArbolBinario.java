package arboles.modelo;

/**
 * @author Brahiam David Tabares Vallejo
 * @author Sandra Milena Quintero Leal
 * @author Tatiana Arboleda Martinez
 */

import estructuras.ListaEnlazada;

public class ArbolBinario<T extends Comparable<T>> {
	private Nodo<T> raiz;
	private Nodo<T> actual;
	private int maxHijos;

	/**
	 * M�todo constructor
	 * 
	 */
	public ArbolBinario() {
		raiz = null;
		actual = null;
		maxHijos = 2;
	}

	/**
	 * M�todo que agrega nodo principal del �rbol
	 * 
	 * @param dato
	 */
	public void agregarRaiz(T dato) {
		Nodo<T> nuevo = new Nodo<T>(dato.toString(), dato);
		raiz = nuevo;
		actual = nuevo;
	}

	/**
	 * M�todo que agrega nodo hijo
	 * 
	 * @param dato 
	 * @param indice
	 */
	public void agregarHijo(T dato, int indice) {
		Nodo<T> nuevo = new Nodo<T>(dato.toString(), dato);
		// int indice= actual.buscarEnlaceLibre();
		if (indice >= 3) {
			System.out.println("ERRORR  se excede");
		} else {
			actual.conectar(nuevo, indice);
			nuevo.conectar(actual, 0);
			actual = nuevo;
		}
	}

	/**
	 * M�todo que se dirige al nodo padre
	 * 
	 */
	public void irAPadre() {
		if (actual != raiz) {
			actual = actual.seguirEnlace(0);
		}

	}

	/**
	 * Metodo set de la clase Albol L-Binario
	 * @param dato 
	 */
	public void setDato(T dato) {
		actual.setDato(dato);
	}

	/**
	 * Metodo que valida si el nodo es una hoja del �rbol
	 */
	public boolean ActualEsHoja() {

		boolean esHoja = false;
		if (actual.getEnlaces().size() == 1) {
			esHoja = true;
		}
		return esHoja;
	}

	/**
	 * Metodo get de la clase Albol L-Binario
	 */
	public T getDato() {
		return actual.getDato();
	}

	public boolean actualEsRaiz() {
		return actual == raiz;
	}

	public void irARaiz() {
		actual = raiz;
	}

	/**
	 * Metodo get que retorna el n�mero de hijos
	 */
	public int getNumeroHijos() {
		int numHijos = actual.getSize() - 1;
		return numHijos;
	}

	public String irAlHijo(int indice) {
		String mensaje = "";
		if (actual.seguirEnlace(indice) == null) {
			mensaje = "No se encontro hijo en ese indice";
		} else {
			actual = actual.seguirEnlace(indice);
		}
		return mensaje;
	}

	/**
	 * Metodo encargado realizar un preorden del �rbol
	 * @param lista 
	 */
	public void preOrden(ListaEnlazada<T> lista) {
		preOrden(actual, lista);
	}

	public void preOrden(Nodo<T> nodo, ListaEnlazada<T> lista) {
		int i;
		T dato;

		if (nodo != null) {
			dato = nodo.getDato();
			lista.agregar(dato);
			for (i = 1; i < nodo.getSize(); i++) {
				if (nodo.estaConectado(i)) {
					preOrden(nodo.seguirEnlace(i), lista);
				}
			}
		}
	}

	/**
	 * Metodo encargado realizar un pos-orden del �rbol
	 * @param lista 
	 */
	public void postOrden(ListaEnlazada<T> lista) {
		postOrden(actual, lista);
	}

	protected void postOrden(Nodo<T> nodo, ListaEnlazada<T> lista) {
		int i;
		T dato;
		if (nodo != null) {
			for (i = 1; i < nodo.getSize(); i++) {
				if (nodo.estaConectado(i)) {
					postOrden(nodo.seguirEnlace(i), lista);
				}
			}
			dato = nodo.getDato();
			lista.agregar(dato);
		}

	}

	/**
	 * Metodo encargado realizar un In-orden del �rbol
	 * @param lista 
	 */
	public void inOrden(ListaEnlazada<T> lista) {
		inOrden(actual, lista);
	}

	public void inOrden(Nodo<T> nodo, ListaEnlazada<T> lista) {
		if (nodo != null) {
			if (nodo.estaConectado(1)) {
				inOrden(nodo.seguirEnlace(1), lista);
			}
			lista.agregar(nodo.getDato());
			if (nodo.estaConectado(2)) {
				inOrden(nodo.seguirEnlace(2), lista);
			}
		}
	}
	/**
	 * Metodo para agregar en binario ordenado
	 * @param dato 
	 */
	
	public void agregarBinarioOrdenado(T dato) {

		if (actual == null) {
			agregarRaiz(dato);
		} else {
			irARaiz();
			agregarOrdenado(dato);
		}
	}

	/**
	 * Metodo para agregar ordenado
	 * @param dato 
	 */
	public void agregarOrdenado(T dato) {
		int indice;
		if (dato.compareTo(actual.getDato()) < 0) {
			indice = 1;
		} else {
			indice = 2;
		}
		if (actual.estaConectado(indice)) {
			actual = actual.seguirEnlace(indice);
			agregarOrdenado(dato);
		} else {
			agregarHijo(dato, indice);
		}
	}
	
	/**
	 * Punto 1 del Parcial
	 * 
	 * M�todo para obtener el elemento mayor de un subArbol
	 * @param dato 
	 */
	
	public T obtenerMayorSubArbol(T dato) {
		Nodo<T> x = buscarNodo(dato);
		ListaEnlazada<T> lista = new ListaEnlazada<>();
		inOrden(x, lista);
		lista.irUltimoNodo();
		return lista.obtenerDatoActual();
	}
	
	/**
	 * Punto 3 del Parcial
	 * 
	 * M�todo para agregar en binario ordenado sin dato repetido
	 * @param dato 
	 */
	
	public void agregarBinarioOrdenadoSinRepetido(T dato) {

		if (actual == null) {
			agregarRaiz(dato);
		} else {
			irARaiz();
			agregarOrdenadoSinRepetido(dato);
		}
	}

	/**
	 * Metodo para agregar ordenado sin dato repetido
	 * @param dato 
	 */
	public void agregarOrdenadoSinRepetido(T dato) {
		int indice;
		int r = dato.compareTo(actual.getDato());
		if( r == 0 ) {
			throw new RuntimeException(String.format("El dato %s ya existe ",dato.toString()));
		} else if ( r < 0) {
			indice = 1;
		} else {
			indice = 2;
		}
		if (actual.estaConectado(indice)) {
			actual = actual.seguirEnlace(indice);
			agregarOrdenadoSinRepetido(dato);
		} else {
			agregarHijo(dato, indice);
		}
	}
	
	/**
	 * M�todo para buscar un dato desde la raiz del �rbol
	 * @param dato 
	 */
	
	public boolean buscarDato(T dato) {
		return buscarDato(raiz, dato);
	}

	protected boolean buscarDato(Nodo<T> nodo, T num) {
		if (nodo != null) {
			int r = num.compareTo(nodo.getDato());
			if (r == 0) {
				return true;
			} else if (r < 0) {
				if (nodo.estaConectado(1)) {
					return buscarDato(nodo.seguirEnlace(1), num);
				}
			} else {
				if (nodo.estaConectado(2)) {
					return buscarDato(nodo.seguirEnlace(2), num);
				}
			}
		}
		return false;
	}
	/**
	 * Metodo para buscar nodo.
	 * @param dato 
	 */
	public Nodo<T> buscarNodo(T dato) {
		return buscarNodo(raiz, dato);
	}

	protected Nodo<T> buscarNodo(Nodo<T> nodo, T num) {
		Nodo<T> aux = null;
		if (nodo != null) {
			int r = num.compareTo(nodo.getDato());
			if (r == 0) {
				return nodo;
			} else if (r < 0) {
				if (nodo.estaConectado(1)) {
					aux = buscarNodo(nodo.seguirEnlace(1), num);
				}
			} else {
				if (nodo.estaConectado(2)) {
					aux = buscarNodo(nodo.seguirEnlace(2), num);
				}
			}
		}
		return aux;
	}

	/**
	 * Punto04 del Parcial
	 * 
	 * M�todo para hallar la distancia entre dos nodos
	 * @param dato1 
	 * @param dato2
	 */
	public int distancia(T dato1, T dato2) {
		Nodo<T> nodo = buscarNodo(dato1);
		if (nodo == null) {
			return -1;
		} else if (dato1.compareTo(dato2) == 0) {
			return -1;
		}

		return distancia(nodo, dato2);
	}

	private int distancia(Nodo<T> nodo, T dato2) {
		int r = nodo.getDato().compareTo(dato2);
		if (r < 0) {
			if (nodo.estaConectado(2)) {
				return 1 + distancia(nodo.seguirEnlace(2), dato2);
			}
		} else if (r > 0 && nodo.estaConectado(1)) {
			return 1 + distancia(nodo.seguirEnlace(1), dato2);
		}
		return -1;
	}
	
	
	/**
	 * Punto05 del Parcial
	 * 
	 * M�todo para eliminar un elemento de un �rbol
	 * @param dato
	 */
	public void eliminar(T dato) {
		Nodo<T> nodo = buscarNodo(dato);
		eliminarNodo(nodo);
	}

	protected void eliminarNodo(Nodo<T> nodo) {
		// Punto 5.1 del Parcial
		if (!nodo.estaConectado(1) && !nodo.estaConectado(2)) {
			if (nodo == raiz) { 
				raiz = null;
				actual = null;
			} else {
				actual = nodo.seguirEnlace(0);
				actual.desconectarDosNodos(nodo.getNombre());
			}
		// Punto 5.2 del Parcial
		} else if ((!nodo.estaConectado(1) && nodo.estaConectado(2))
				|| (nodo.estaConectado(1) && !nodo.estaConectado(2))) {

			int indice;
			if (nodo.estaConectado(1)) {
				indice = 1;
			} else {
				indice = 2;
			}

			if (nodo == raiz) {
				raiz = raiz.seguirEnlace(indice);
				raiz.desconectar(0);
				actual = raiz;
			} else {
				actual = nodo.seguirEnlace(0);
				actual.desconectarDosNodos(nodo.getNombre());
				if (actual.getDato().compareTo(nodo.seguirEnlace(indice).getDato()) < 0) {
					actual.conectar(nodo.seguirEnlace(indice), 2);
				} else {
					actual.conectar(nodo.seguirEnlace(indice), 1);
				}
				nodo.seguirEnlace(indice).conectar(actual, 0);
			}
			// Punto 5.3 del Parcial
		} else {
			Nodo<T> aux = obtenerNodoExtremoDerecho(nodo.seguirEnlace(1));

			aux.seguirEnlace(0).desconectarDosNodos(aux.getNombre());

			Nodo<T> hI = obtenerNodoExtremoIzquierdo(aux);
			hI.conectar(nodo.seguirEnlace(1), 1);
			nodo.seguirEnlace(1).conectar(hI, 0);

			aux.conectar(nodo.seguirEnlace(2), 2);
			nodo.seguirEnlace(2).conectar(aux, 0);

			if (nodo == raiz) {
				raiz = aux;
				raiz.desconectar(0);
			} else {
				aux.conectar(nodo.seguirEnlace(0), 0);
				if (aux.getDato().compareTo(nodo.seguirEnlace(0).getDato()) < 0) {
					nodo.seguirEnlace(0).conectar(aux, 1);
				} else {
					nodo.seguirEnlace(0).conectar(aux, 2);
				}
			}
			actual = aux;

		}

	}

	/**
	 * 
	 * M�todo para obtener el nodo extremo derecho del �rbol
	 * 
	 * @param nodo
	 */
	private Nodo<T> obtenerNodoExtremoDerecho(Nodo<T> nodo) {
		if (nodo.estaConectado(2)) {
			return obtenerNodoExtremoDerecho(nodo.seguirEnlace(2));
		}
		return nodo;
	}
	
	
	/**
	 * 
	 * M�todo para obtener el nodo extremo izquierdo del �rbol
	 * 
	 * @param nodo
	 */
	private Nodo<T> obtenerNodoExtremoIzquierdo(Nodo<T> nodo) {
		if (nodo.estaConectado(1)) {
			return obtenerNodoExtremoIzquierdo(nodo.seguirEnlace(1));
		}
		return nodo;
	}


	
	@Override
	public String toString() {
		return "ArbolBinario [raiz=" + raiz + " \nActual=" + actual + " \nmaxHijos=" + maxHijos + "]";
	}

}
