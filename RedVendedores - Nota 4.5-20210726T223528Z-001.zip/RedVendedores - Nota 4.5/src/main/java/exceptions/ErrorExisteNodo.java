package exceptions;

public class ErrorExisteNodo extends Exception{

	public ErrorExisteNodo(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
