package exceptions;

public class ErrorNodosConectados extends Exception{

	public ErrorNodosConectados(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
