package exceptions;

public class ErrorMaximoVendedoresEnRed extends Exception{

	public ErrorMaximoVendedoresEnRed(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
