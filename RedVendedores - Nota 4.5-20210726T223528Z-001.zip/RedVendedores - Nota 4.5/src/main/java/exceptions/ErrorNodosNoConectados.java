package exceptions;

public class ErrorNodosNoConectados extends Exception{

	public ErrorNodosNoConectados(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
