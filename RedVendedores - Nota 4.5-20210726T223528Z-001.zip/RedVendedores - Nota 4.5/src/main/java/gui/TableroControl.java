package gui;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

import exceptions.ErrorExisteNodo;
import exceptions.ErrorMaximoVendedoresEnRed;
import exceptions.ErrorNodoNoExiste;
import exceptions.ErrorNodosNoConectados;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Producto;
import model.Vendedor;

public class TableroControl extends ControladorGeneral {

	@FXML
	private TextField nuevoVendedor;

	@FXML
	private ComboBox<Vendedor> comboVendedores;

	@FXML
	private VBox panelProductos;
	
	@FXML
	private DatePicker fechaInicial;
	
	@FXML
	private DatePicker fechaFinal;

	@FXML
	public void verMuro() {
		Vendedor vendedor = comboVendedores.getValue();
		if (vendedor != null) {
			try {
				Stage dialog = new Stage();
				dialog.setTitle("Muro - "+vendedor.getNombre());
				
				String vistaActiva = "/gui/VentanaVendedor2.fxml";
				FXMLLoader loader = new FXMLLoader(getClass().getResource(vistaActiva));
				ScrollPane ventana = loader.load();
				ControladorVentanaVendedor controller = loader.getController();
				controller.setVendedor(vendedor);		
				
				// populate dialog with controls.

				Scene scene = new Scene(ventana);

				dialog.setScene(scene);
				dialog.initOwner(Principal.stage.getOwner());
				dialog.initModality(Modality.APPLICATION_MODAL);
				dialog.showAndWait();
				
				

			} catch (IOException ex) {
				ex.printStackTrace();
			}
			
		}
	}
	
	private void actualizarProductos(){
		String vistaActiva = "/gui/PanelProductoVista.fxml";
		panelProductos.getChildren().clear();
		for (Producto producto : Principal.redSocial.obtenerTopMasMeGusta()) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource(vistaActiva));
				Pane modalRegisterBrand = loader.load();
				PanelProducto controller = loader.getController();
				controller.setProducto(producto);
				controller.ocultarControles();
				panelProductos.getChildren().add(modalRegisterBrand);

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

	@FXML
	public void crearVendedor() {
		try {
			Principal.redSocial.crearVendedor(nuevoVendedor.getText());
			
			mostrarMensaje("Se creo el vendedor " + nuevoVendedor.getText());
			actualizarComboVendedores();
			nuevoVendedor.setText("");
		} catch (ErrorExisteNodo e) {
			mostrarError("El vendedor ya existe");
		} catch (ErrorMaximoVendedoresEnRed e) {
			mostrarError(e.getMessage());
		}
	}

	@FXML
	public void cantidadProductos() {
		Vendedor vendedor = comboVendedores.getValue();
		if (vendedor != null) {
			int cantidad;
			try {
				cantidad = Principal.redSocial.obtenerCantidadPdctosPublicadosVendedor(vendedor.getNombre());
				mostrarMensaje("Cantidad de publicaciones del vendedor " + vendedor + " es: " + cantidad);
			} catch (Exception e) {
				mostrarError("Error "+e.getMessage());
			}
		}
	}

	private void actualizarComboVendedores() {
		comboVendedores.getItems().clear();
		for (Vendedor vendedor : Principal.redSocial.obtenerListaVendedores()) {
			comboVendedores.getItems().add(vendedor);
		}
	}
	@FXML
	public void cantidadEntreFechas() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YYYY-MM-dd"); 
		String fecha1 = fechaInicial.getValue().format(formatter);
		String fecha2 = fechaFinal.getValue().format(formatter);
		
		int cant= Principal.redSocial.obtenerCantidadPublicacionesEntreFechas(fecha1, fecha2+ " 23:59");
		mostrarMensaje(" La cantidad de pubicaciones entre la fecha "+ fecha1+" y la fecha final "+fecha2+ " es:\n"+cant);
		
	}
	
	@FXML
	public void crearRedSocial() {

		try {
			// Crear vendedores
			Principal.redSocial.crearVendedor("Juan");
			Principal.redSocial.crearVendedor("Tatiana");
			Principal.redSocial.crearVendedor("Brahiam");
			Principal.redSocial.crearVendedor("Sandra");
			Principal.redSocial.crearVendedor("Karina");
			Principal.redSocial.crearVendedor("Marcela");
			Principal.redSocial.crearVendedor("Diana");

			// Conectarlos
			Principal.redSocial.conectarVendedores("Juan", "Tatiana");
			Principal.redSocial.conectarVendedores("Juan", "Brahiam");
			Principal.redSocial.conectarVendedores("Juan", "Sandra");
			Principal.redSocial.conectarVendedores("Juan", "Karina");
			Principal.redSocial.conectarVendedores("Tatiana", "Karina");
			Principal.redSocial.conectarVendedores("Tatiana", "Brahiam");
			Principal.redSocial.conectarVendedores("Sandra", "Tatiana");
			Principal.redSocial.conectarVendedores("Sandra", "Karina");
			Principal.redSocial.conectarVendedores("Brahiam", "Marcela");
			Principal.redSocial.conectarVendedores("Marcela", "Karina");

			// Crear productos
			Producto p1 = Principal.redSocial.crearProducto("Juan", "Electrodoméstico", "Televisor LG 32",
					"2020-11-21 13:34");
			Producto p2 = Principal.redSocial.crearProducto("Juan", "Electrodoméstico", "Televisor SAMSUMG",
					"2020-11-17 08:17");
			Producto p3 = Principal.redSocial.crearProducto("Juan", "Electrodoméstico", "Televisor LG 55",
					"2020-11-01 18:54");
			Producto p4 = Principal.redSocial.crearProducto("Tatiana", "Electrodoméstico", "Cámara Web Genius",
					"2020-11-25 13:01");
			Producto p5 = Principal.redSocial.crearProducto("Tatiana", "Cafetería y Panadería", "Café Especial Ginebra",
					"2020-12-01 15:04");
			Producto p6 = Principal.redSocial.crearProducto("Brahiam", "Deportes", "Guantes de Boxeo",
					"2020-12-01 09:10");
			Producto p7 = Principal.redSocial.crearProducto("Sandra", "Instrumentos Musicales",
					"Guitarra Electro-Acústica", "2020-11-22 11:12");
			Producto p8 = Principal.redSocial.crearProducto("Sandra", "Instrumentos Musicales", "Ukulele",
					"2020-11-22 13:34");
			Producto p9 = Principal.redSocial.crearProducto("Karina", "Librería", "Libro Aprendiendo a Programar",
					"2020-11-30 13:09");
			Producto p10 = Principal.redSocial.crearProducto("Karina", "Librería",
					"Libro Estructura de Datos para Dummiens", "2020-11-21 10:04");
			Producto p11 = Principal.redSocial.crearProducto("Karina", "Librería",
					"Libro No Compilo, vida del ingeniero", "2020-12-01 21:37");
			Producto p12 = Principal.redSocial.crearProducto("Karina", "Papelería", "Cuaderno cuadriculado 100 hojas",
					"2020-11-17 08:37");
			Producto p13 = Principal.redSocial.crearProducto("Marcela", "Alimentos y bebidas", "Cerveza Michela",
					"2020-12-01 18:07");
			Producto p14 = Principal.redSocial.crearProducto("Karina", "Librería",
					"Tomo de las 21 embolatadas en código", "2020-12-01 21:37");
			Producto p15 = Principal.redSocial.crearProducto("Diana", "Librería", "Libro Gozar mientras se sufre",
					"2020-12-01 21:35");

			// Crear Me gustas

			Principal.redSocial.crearMeGusta("Juan", p14);
			Principal.redSocial.crearMeGusta("Tatiana", p14);
			Principal.redSocial.crearMeGusta("Sandra", p14);
			Principal.redSocial.crearMeGusta("Marcela", p14);
			Principal.redSocial.crearMeGusta("Juan", p6);
			Principal.redSocial.crearMeGusta("Tatiana", p6);
			Principal.redSocial.crearMeGusta("Sandra", p3);
			Principal.redSocial.crearMeGusta("Tatiana", p1);
			Principal.redSocial.crearMeGusta("Tatiana", p2);
			Principal.redSocial.crearMeGusta("Tatiana", p3);
			Principal.redSocial.crearMeGusta("Brahiam", p13);
			Principal.redSocial.crearMeGusta("Karina", p13);
			Principal.redSocial.crearMeGusta("Marcela", p11);
			Principal.redSocial.crearMeGusta("Juan", p7);
			Principal.redSocial.crearMeGusta("Juan", p8);
			Principal.redSocial.crearMeGusta("Tatiana", p8);
			Principal.redSocial.crearMeGusta("Sandra", p8);
			Principal.redSocial.crearMeGusta("Sandra", p9);
			Principal.redSocial.crearMeGusta("Sandra", p5);

			// Crear Comentarios

			Principal.redSocial.crearComentario("Juan", "Necesito 10 libros", p14);
			Principal.redSocial.crearComentario("Tatiana", "Cuánto es el precio al por mayor?", p14);
			Principal.redSocial.crearComentario("Marcela", "Aceptan convenios con Universidades?", p14);
			Principal.redSocial.crearComentario("Tatiana", "Son de muy buena calidad", p1);
			Principal.redSocial.crearComentario("Sandra", "Tienes de otros colores?", p1);
			Principal.redSocial.crearComentario("Juan", "Mi hija quiere uno, es electroacústico", p8);
			Principal.redSocial.crearComentario("Sandra", "Excelentes acabados y garantía de 3 años", p8);
			Principal.redSocial.crearComentario("Tatiana", "Hacen envío a Putumayo?", p8);
			Principal.redSocial.crearComentario("Sandra", "Tatiana, por supuesto, se hace por ServiTenga", p8);

			actualizarComboVendedores();
			actualizarProductos();

			mostrarMensaje("Se creo la red con exito");
		} catch (ErrorExisteNodo | ErrorMaximoVendedoresEnRed | ErrorNodoNoExiste e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ErrorNodosNoConectados e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
