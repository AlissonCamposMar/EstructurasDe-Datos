package gui;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ControladorGeneral {

// cuadros de dialogo
	
	public void mostrarMensaje(String mensaje) {
		mostrarMensaje(AlertType.INFORMATION, mensaje);
	}

	public void mostrarError(String mensaje) {
		mostrarMensaje(AlertType.ERROR, mensaje);
	}

	private void mostrarMensaje(AlertType tipo, String mensaje) {
		Alert alert = new Alert(tipo);
		alert.setTitle("RED SOCIAL");
		alert.setHeaderText(null);
		alert.setContentText(mensaje);
		alert.showAndWait();
	}

}
