package gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.stage.Stage;
import model.RedSocial;

public class Principal  extends Application {
	
	public static final RedSocial redSocial = new RedSocial();
	public static Stage stage;
	@Override
	public void start(Stage primaryStage) { // configura el inicio de sesion
		try {
			stage = primaryStage;
			String vistaActiva = "/gui/TableroControlIndicadoresVista.fxml";
			ScrollPane root = (ScrollPane)FXMLLoader.load(getClass().getResource(vistaActiva));
			Scene scene = new Scene(root,1100,690);
			//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); // hoja de estilos para el diseno de la interfaz
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	

	
	public static void main(String[] args) {
		launch(args); // Esto es para lanzar las interfaces
	}
	
}
