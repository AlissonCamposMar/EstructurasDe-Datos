package gui;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import estructuras.ListaEnlazada;
import exceptions.ErrorExisteNodo;
import exceptions.ErrorNodoNoExiste;
import exceptions.ErrorNodosConectados;
import exceptions.ErrorNodosNoConectados;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import model.Chat;
import model.Mensaje;
import model.Producto;
import model.Vendedor;

public class ControladorVentanaVendedor extends ControladorGeneral {

	private static final String TODOS_LOS_POSIBLES_CONTACTOS = "Todos los posibles contactos";
	private static final String CONTACTOS_SUGERIDOS = "Contactos sugeridos";
	private Vendedor vendedor;
	@FXML
	private VBox misProductos;
	@FXML
	private VBox miRedProductos;

	@FXML
	private TextField categoriaProducto;
	@FXML
	private ComboBox<String> buscarVendedorLista;
	@FXML
	private ComboBox<Vendedor> chatVendedor;
	@FXML
	private TextField nombreProducto;

	@FXML
	private TextField chatMensaje;
	@FXML
	private TextArea chatSugeridos;
	@FXML
	private ListView<Vendedor> buscarSugeridos;

	@FXML
	private void initialize() {
		buscarVendedorLista.getItems().add(CONTACTOS_SUGERIDOS);
		buscarVendedorLista.getItems().add(TODOS_LOS_POSIBLES_CONTACTOS);
	}

	@FXML
	public void seleccionBusquedaContactos() {
		String opcion = buscarVendedorLista.getValue();
		ListaEnlazada<Vendedor> sugeridos;
		try {
			if (CONTACTOS_SUGERIDOS.equals(opcion)) {
				sugeridos = Principal.redSocial.obtenerListaVendedoresSugeridos(vendedor.getNombre());
			} else if (TODOS_LOS_POSIBLES_CONTACTOS.equals(opcion)) {
				sugeridos = Principal.redSocial.obtenerListaTodosPosiblesContactos(vendedor.getNombre());
			} else {
				sugeridos = new ListaEnlazada<Vendedor>();
			}
			actualizarSugeridos(sugeridos);
		} catch (ErrorNodoNoExiste | ErrorNodosConectados | ErrorExisteNodo e) {
			mostrarError(e.getMessage());
			e.printStackTrace();
		}
	}

	private void actualizarSugeridos(ListaEnlazada<Vendedor> sugeridos) {
		buscarSugeridos.getItems().clear();
		for(Vendedor vendedor:sugeridos) {
			buscarSugeridos.getItems().add(vendedor);
		}
	}

	/**
	 * Metodo que permite asignar un valor al atributo vendedor
	 * 
	 * @param vendedor Valor a ser asignado al atributo vendedor
	 */
	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
		actualizarContactos();
		actualizarMisProductos();
		actualizarMiRedProductos();
	}

	private void actualizarContactos() {
		chatVendedor.getItems().clear();
		try {
			for (Vendedor vendedor : Principal.redSocial.obtenerListaContactos(vendedor.getNombre())) {
				chatVendedor.getItems().add(vendedor);
			}
		} catch (ErrorNodoNoExiste | ErrorNodosConectados | ErrorExisteNodo e) {
			mostrarError(e.getMessage());
		}
	}

	private void actualizarMiRedProductos() {
		miRedProductos.getChildren().clear();
		try {
			for (Producto producto : Principal.redSocial.obtenerListaProductosContactosFecha(vendedor.getNombre())) {
				miRedProductos.getChildren().add(crearPanelProducto(producto));
			}
		} catch (ErrorNodoNoExiste e) {
			mostrarError("No existe el vendedor");
			e.printStackTrace();
		} catch (ErrorNodosConectados e) {
			mostrarError("Vendedores no conectados");
			e.printStackTrace();
		} catch (ErrorExisteNodo e) {
			mostrarError("Error al obtener los datos de la red");
			e.printStackTrace();
		}
	}

	private Pane crearPanelProducto(Producto producto) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/PanelProductoVista.fxml"));
			Pane panel = loader.load();
			PanelProducto controller = loader.getController();
			controller.setProducto(producto);
			controller.setVendedor(vendedor);
			return panel;
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	private void actualizarMisProductos() {
		misProductos.getChildren().clear();
		try {
			for (Producto producto : Principal.redSocial.obtenerListaProductosVendedorPorFecha(vendedor.getNombre())) {
				misProductos.getChildren().add(crearPanelProducto(producto));
			}
		} catch (ErrorNodoNoExiste e) {
			mostrarError("No existe el vendedor");
		}
	}

	@FXML
	public void crearNuevoProducto() {
		if (categoriaProducto.getText().isEmpty() || nombreProducto.getText().isEmpty()) {
			mostrarError("Los campos son requeridos");
		} else {
			SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd HH:mm");
			try {
				Producto nuevo = Principal.redSocial.crearProducto(vendedor.getNombre(), categoriaProducto.getText(),
						nombreProducto.getText(), format.format(new Date()));
				mostrarMensaje("Producto creado");
				categoriaProducto.setText("");
				nombreProducto.setText("");
				misProductos.getChildren().add(0, crearPanelProducto(nuevo));
			} catch (ErrorNodoNoExiste e) {
				mostrarError("No existe el vendedor");
			}
		}
	}

	@FXML
	public void conectarVendedor() {
		Vendedor nuevoContacto = buscarSugeridos.getSelectionModel().getSelectedItem();
		if( nuevoContacto != null ) {
			try {
				Principal.redSocial.conectarVendedores(vendedor.getNombre(), nuevoContacto.getNombre());
				mostrarMensaje("Se adiciono el contacto");
				seleccionBusquedaContactos();
				actualizarContactos();
			} catch (ErrorNodoNoExiste e) {
				mostrarError(e.getMessage());
				e.printStackTrace();
			}
		}
	}
	
	@FXML
	public void seleccionContactoChat() {
		Vendedor contacto = chatVendedor.getValue();
		if( contacto != null ) {
			try {
				chatSugeridos.clear();
				Chat chat = Principal.redSocial.obtenerChat(vendedor.getNombre(), contacto.getNombre());
				
				for(Mensaje mensaje:chat.getMensajes()) {
					chatSugeridos.appendText( mensaje.getEmisor().getNombre()+":"+mensaje.getMensaje()+"\n" );
				}
				
			} catch (ErrorNodoNoExiste e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@FXML
	public void enviarMensajeVendedor() {
		Vendedor contacto = chatVendedor.getValue();
		if( contacto != null && !chatMensaje.getText().isEmpty()) {
			try {
				Principal.redSocial.crearMensaje(vendedor.getNombre(), contacto.getNombre(), chatMensaje.getText());
				chatSugeridos.appendText( vendedor.getNombre()+":"+chatMensaje.getText()+"\n" );
			} catch (ErrorNodoNoExiste | ErrorNodosNoConectados e) {
				mostrarError(e.getMessage());
				e.printStackTrace();
			}
		}
	}

}
