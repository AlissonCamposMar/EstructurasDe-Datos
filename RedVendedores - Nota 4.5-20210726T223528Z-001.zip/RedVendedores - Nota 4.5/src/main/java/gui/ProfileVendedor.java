package gui;

public class ProfileVendedor {

}
