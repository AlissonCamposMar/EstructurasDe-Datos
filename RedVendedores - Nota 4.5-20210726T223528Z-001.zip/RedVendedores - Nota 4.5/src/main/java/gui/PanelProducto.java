package gui;


import exceptions.ErrorNodoNoExiste;
import exceptions.ErrorNodosNoConectados;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import model.Producto;
import model.Vendedor;

public class PanelProducto extends ControladorGeneral{
    @FXML
    private Label lbFecha;
    @FXML
    private Label lbProducto;
    @FXML
    private Label lbMegustas;
    private Producto producto;
    
    private Vendedor vendedor=null;
    @FXML
    private ImageView imgComentarios;
    @FXML
    private Label lbComentarios;
    @FXML
    private ImageView imgComentar;
    @FXML
    private Label lbComentar;
    
    
    public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public void setProducto(Producto producto) {
        this.producto = producto;
        lbFecha.setText( producto.getFechaPublicacion() );
        lbProducto.setText( producto.getCategoria() + " - " + producto.getNombre() );
        lbMegustas.setText( "("+producto.getMeGustas().getLongitud()+")" );
    }
    
    public void ocultarControles() {
    	lbComentar.setVisible(false);
    	lbComentarios.setVisible(false);
    	imgComentar.setVisible(false);
    	imgComentarios.setVisible(false);
    }
    @FXML
    public void meGusta() {
    	if (vendedor!=null) {
    		try {
				Principal.redSocial.crearMeGusta(vendedor.getNombre(), producto);
				lbMegustas.setText( "("+producto.getMeGustas().getLongitud()+")" );
			} catch (ErrorNodoNoExiste | ErrorNodosNoConectados e) {
				mostrarError(e.getMessage());
			}
    	}
    }
}
