package model;

public class MeGusta {
	private Vendedor vendedor;
	private Producto producto;

	/*
	 * Constructor para la clase MeGusta
	 * 
	 * @Param vendedor y producto
	 */
	public MeGusta(Vendedor vendedor, Producto producto) {
		super();
		this.vendedor = vendedor;
		this.producto = producto;
	}

	/*
	 * Métodos get y set de la clase MeGusta
	 */
	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

}
