package model;

import java.util.HashMap;
import arboles.modelo.ArbolBinario;
import estructuras.ListaEnlazada;

public class Vendedor {

	private String nombre;
	private ArbolBinario<Producto> productos;
	private HashMap<String, Chat> chats;

	/*
	 * Constructor de la clase Vendedor
	 * 
	 * @Param nombre
	 */
	public Vendedor(String nombre) {
		super();
		this.nombre = nombre;
		chats = new HashMap<String, Chat>();
		productos = new ArbolBinario<Producto>();
	}

	/*
	 * Método para crear un producto Valida si el nombre está repetido
	 * 
	 * @Param categoría, nombre y fecha
	 */
	public Producto crearProducto(String categoria, String nombre, String fecha) {
		Producto producto = new Producto(categoria, nombre, fecha, this);
		productos.agregarBinarioOrdenadoSinRepetido(producto);
		return producto;
	}

	/*
	 * Método para crear un chat con un vendedor
	 * 
	 * @Param nombreVendedor y chat
	 */
	public void adicionarChat(String nombreVendedor, Chat chat) {
		chats.put(nombreVendedor, chat);
	}

	/*
	 * Métodos get y set de la clase Vendedor
	 */

	public void adicionarMensaje(String nombreVendedor, Mensaje mensaje) {
		chats.get(nombreVendedor).adicionarMensaje(mensaje);
	}

	public Chat obtenerChat(String contacto) {
		return chats.get(contacto);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ListaEnlazada<Producto> obtenerProductos() {

		ListaEnlazada<Producto> listaProductos = new ListaEnlazada<Producto>();
		productos.irARaiz();
		productos.inOrden(listaProductos);
		return listaProductos;
	}

	/*
	 * Metodo toString Metodo que imprime el vendedor con sus parametros
	 * concatenados
	 */
	@Override
	public String toString() {
		return nombre;
	}

}
