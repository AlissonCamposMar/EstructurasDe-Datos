package model;

public class Comentario {

	private Vendedor emisor;
	private String comentario;
	private Producto producto;

	/*
	 * Constructor para la clas Comentario
	 * 
	 * @Param emisor, comentario y producto
	 */
	public Comentario(Vendedor emisor, String comentario, Producto producto) {
		super();
		this.emisor = emisor;
		this.comentario = comentario;
		this.producto = producto;
	}

	/*
	 * Métodos get y set de la clase Comentario
	 */
	public Vendedor getEmisor() {
		return emisor;
	}

	public void setEmisor(Vendedor emisor) {
		this.emisor = emisor;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

}
