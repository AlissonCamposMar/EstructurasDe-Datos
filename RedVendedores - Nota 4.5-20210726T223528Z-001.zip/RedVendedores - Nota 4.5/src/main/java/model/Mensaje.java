package model;

public class Mensaje {
	private Vendedor emisor;
	private Vendedor receptor;
	private String mensaje;

	/*
	 * Constructor para la clase Mensaje
	 * 
	 * @Param emisor, receptor y mensaje
	 */
	public Mensaje(Vendedor emisor, Vendedor receptor, String mensaje) {
		super();
		this.emisor = emisor;
		this.receptor = receptor;
		this.mensaje = mensaje;
	}

	/*
	 * Métodos get y set de la clase Mensaje
	 */
	public Vendedor getEmisor() {
		return emisor;
	}

	public void setEmisor(Vendedor emisor) {
		this.emisor = emisor;
	}

	public Vendedor getReceptor() {
		return receptor;
	}

	public void setReceptoror(Vendedor receptor) {
		this.receptor = receptor;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

}
