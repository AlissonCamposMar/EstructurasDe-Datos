package model;

import arboles.modelo.ArbolBinario;
import estructuras.ListaEnlazada;
import estructuras.grafos.GrafoNoDirigido;
import exceptions.ErrorExisteNodo;
import exceptions.ErrorMaximoVendedoresEnRed;
import exceptions.ErrorNodoNoExiste;
import exceptions.ErrorNodosConectados;
import exceptions.ErrorNodosNoConectados;

public class RedSocial {

	GrafoNoDirigido vendedores = new GrafoNoDirigido();

	/*
	 * Método que crea un vendedor Valida que no hayan más de 10 personas creadas
	 * 
	 * @Param nombre
	 */
	public void crearVendedor(String nombre) throws ErrorExisteNodo, ErrorMaximoVendedoresEnRed {
		Vendedor vendedor = new Vendedor(nombre);
		if (vendedores.getSize() < 10) {
			vendedores.agregar(nombre, vendedor);
		} else
			throw new ErrorMaximoVendedoresEnRed(" No se puede crear vendedor, supera cantidad permitida en red");
	}

	/*
	 * Método que permite que un vendedor agregue a otro a su lista de amigos
	 * Inicializa el chat para que estos dos puedan comenzar una conversación si lo
	 * desean
	 * 
	 * @Param vendedor1 y vendedor2
	 */
	public void conectarVendedores(String vendedor1, String vendedor2) throws ErrorNodoNoExiste {
		vendedores.conectar(vendedor1, vendedor2);
		Chat chat = new Chat(vendedores.getDato(vendedor1), vendedores.getDato(vendedor2));
		vendedores.getDato(vendedor1).adicionarChat(vendedor2, chat);
		vendedores.getDato(vendedor2).adicionarChat(vendedor1, chat);
	}

	/*
	 * Método que permite crear el mensaje que se quiera enviar a un contacto de la
	 * lista de amigos Valida que los vendedores estén conectados entre sí
	 * 
	 * @Param emisor, receptor y mensaje
	 */
	public void crearMensaje(String emisor, String receptor, String mensaje)
			throws ErrorNodoNoExiste, ErrorNodosNoConectados {

		if (vendedores.estaConectado(emisor, receptor)) {
			Mensaje nuevoMensaje = new Mensaje(vendedores.getDato(emisor), vendedores.getDato(receptor), mensaje);
			vendedores.getDato(emisor).adicionarMensaje(receptor, nuevoMensaje);
		} else {
			throw new ErrorNodosNoConectados("Los vendedores no estás asociados");
		}
	}

	/*
	 * Método que permite crear un producto
	 * 
	 * @Param vendedor, categoría, nombre y fecha
	 */
	public Producto crearProducto(String vendedor, String categoria, String nombre, String fecha)
			throws ErrorNodoNoExiste {
		return vendedores.getDato(vendedor).crearProducto(categoria, nombre, fecha);
	}

	/*
	 * Método que permite crear comentario en un producto
	 * 
	 * @Param emisor, comentario y producto
	 */
	public void crearComentario(String emisor, String comentario, Producto producto)
			throws ErrorNodoNoExiste, ErrorNodosNoConectados {

		if (emisor.equals(producto.getVendedor().getNombre())
				|| vendedores.estaConectado(emisor, producto.getVendedor().getNombre())) {
			Comentario nuevoComentario = new Comentario(vendedores.getDato(emisor), comentario, producto);
			producto.adicionarComentario(nuevoComentario);
		} else {
			throw new ErrorNodosNoConectados("Los vendedores no estás asociados");
		}
	}

//	  - crearMeGusta
	/*
	 * Método que permite crear un MeGusta en uno de los productos que pertenezcan a
	 * un contacto del vendedor
	 * 
	 * @Param emisor y producto
	 */

	public void crearMeGusta(String emisor, Producto producto) throws ErrorNodoNoExiste, ErrorNodosNoConectados {
		if (emisor.equals(producto.getVendedor().getNombre())
				|| vendedores.estaConectado(emisor, producto.getVendedor().getNombre())) {
			MeGusta nuevoMeGusta = new MeGusta(vendedores.getDato(emisor), producto);
			producto.adicionarMeGusta(nuevoMeGusta);
		} else {
			throw new ErrorNodosNoConectados("Los vendedores no estás asociados");
		}

	}

	/*
	 * Método que permite obtener los amigos que le pertenecen a un vendedor
	 * 
	 * @Param vendedor
	 */
	public ListaEnlazada<Vendedor> obtenerListaContactos(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		GrafoNoDirigido subgrafo = vendedores.retornarSubGrafo(vendedor);

		ListaEnlazada<Vendedor> temporal = subgrafo.getDatos();
		temporal.eliminarNodoElementoX(vendedores.getDato(vendedor));

		return temporal;
	}

//	 - obtenerListaTodosPosiblesContactos	-- lista que almacene los que no estan conectados	
	/*
	 * Método que permite obtener la lista de los posibles contactos del vendedor
	 * Además permite almacenar los que no están conectados
	 * 
	 * @Param vendedor
	 */
	public ListaEnlazada<Vendedor> obtenerListaTodosPosiblesContactos(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		ListaEnlazada<Vendedor> todosLosVendedores = vendedores.getDatos();
		GrafoNoDirigido subgrafo = vendedores.retornarSubGrafo(vendedor);
		ListaEnlazada<Vendedor> temporal = subgrafo.getDatos();
		for (Vendedor vendedor2 : temporal) {
			todosLosVendedores.eliminarNodoElementoX(vendedor2);
		}
		return todosLosVendedores;
	}

	/*
	 * Método que permite sugerir contactos a un vendedor
	 * 
	 * @Param vendedor
	 */
	public ListaEnlazada<Vendedor> obtenerListaVendedoresSugeridos(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		ListaEnlazada<Vendedor> contactos = obtenerListaContactos(vendedor);
		ListaEnlazada<Vendedor> contactosSugeridos = new ListaEnlazada<Vendedor>();

		for (Vendedor vendedor2 : contactos) {
			ListaEnlazada<Vendedor> contactosDeContactos = obtenerListaContactos(vendedor2.getNombre());
			for (Vendedor vendedor3 : contactosDeContactos) {
				if (contactos.buscarElementoLista(vendedor3) == -1
						&& contactosSugeridos.buscarElementoLista(vendedor3) == -1
						&& !vendedor3.getNombre().equals(vendedor)) {
					contactosSugeridos.agregarFinal(vendedor3);
				}
			}
		}
		return contactosSugeridos;
	}

//	 - obtenerListaDeMeGusta
	/*
	 * Método que permite obtener la lista de los MeGusta que ha obtenido un
	 * producto
	 * 
	 * @Param vendedor y producto
	 */

	public ListaEnlazada<MeGusta> obtenerListaDeMeGusta(String vendedor, Producto producto)
			throws ErrorNodosNoConectados, ErrorNodoNoExiste {

		if (vendedores.estaConectado(vendedor, producto.getVendedor().getNombre())) {
			ListaEnlazada<MeGusta> listaMeGusta = producto.getMeGustas();
			return listaMeGusta;
		} else {
			throw new ErrorNodosNoConectados("Los vendedores no estás asociados");
		}
	}
//	 - obtenerTopMasMeGusta

	/*
	 * Método que permite mostrar y ordenar los productos segun su cantidad de
	 * MeGusta
	 */
	public ListaEnlazada<Producto> obtenerTopMasMeGusta() {

		ListaEnlazada<Vendedor> listaTodosLosVendedores = vendedores.getDatos();
		ListaEnlazada<Producto> productosGenerales = new ListaEnlazada<Producto>();

		for (Vendedor vendedor : listaTodosLosVendedores) {
			ListaEnlazada<Producto> productos = vendedor.obtenerProductos();
			for (Producto producto1 : productos) {
				productosGenerales.agregarFinal(producto1);
			}

		}

		Producto arreglo[] = new Producto[productosGenerales.getLongitud()];
		int i = 0;
		for (Producto producto : productosGenerales) {

			arreglo[i] = producto;
			i++;

		}

		// ordena de mayor a menor cantidad de me gustas
		for (i = 0; i < arreglo.length - 1; i++) {
			for (int j = i + 1; j < arreglo.length; j++) {
				if (arreglo[i].obtenerCantidadMeGustas() < arreglo[j].obtenerCantidadMeGustas()) {
					Producto aux = arreglo[i];
					arreglo[i] = arreglo[j];
					arreglo[j] = aux;
				}
			}
		}

		productosGenerales.vaciarLista();

		for (i = 0; i < 10 && i < arreglo.length; i++) {
			productosGenerales.agregarFinal(arreglo[i]);
		}

		return productosGenerales;
	}

	/*
	 * Método que permite obtener la lista de los productos de los contactos del
	 * vendedor y muestra desde la publicación del producto más reciente hasta la
	 * más antigua
	 * 
	 * @Param vendedor
	 */
	public ListaEnlazada<Producto> obtenerListaProductosContactosFecha(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		ListaEnlazada<Producto> listaGnralPdctos = new ListaEnlazada<Producto>();
		ListaEnlazada<Vendedor> contactos = obtenerListaContactos(vendedor);

		for (Vendedor vendedor2 : contactos) {
			ListaEnlazada<Producto> temporal = vendedor2.obtenerProductos();
			for (Producto producto : temporal) {
				listaGnralPdctos.agregarFinal(producto);
			}
		}

		Producto arreglo[] = new Producto[listaGnralPdctos.getLongitud()];
		int i = 0;
		for (Producto producto : listaGnralPdctos) {

			arreglo[i] = producto;
			i++;

		}

		// ordena por fecha actual a mas vieja
		for (i = 0; i < arreglo.length - 1; i++) {
			for (int j = i + 1; j < arreglo.length; j++) {
				// El compareTo retorna un 0 sin son iguales, < 0 si es alfabeticamente menor y
				// > 0 si es alfabeticamente mayor
				if (arreglo[i].getFechaPublicacion().compareTo(arreglo[j].getFechaPublicacion()) < 0) {
					Producto aux = arreglo[i];
					arreglo[i] = arreglo[j];
					arreglo[j] = aux;
				}
			}
		}

		listaGnralPdctos.vaciarLista();

		for (i = 0; i < arreglo.length; i++) {
			listaGnralPdctos.agregarFinal(arreglo[i]);
		}

		return listaGnralPdctos;
	}

//	 - obtenerListaProductosContactos Alfabeticamente	
	/*
	 * Método que permite obtener la lista de los productos de un vendedor ordenados
	 * de manera alfabética
	 * 
	 * @Param vendedor
	 */

	public ListaEnlazada<Producto> obtenerListaProductosContactosAlfabeticamente(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		ListaEnlazada<Producto> listaGnralPdctos = new ListaEnlazada<Producto>();
		ListaEnlazada<Vendedor> contactos = obtenerListaContactos(vendedor);
		ArbolBinario<Producto> ordenProductos = new ArbolBinario<Producto>();
		for (Vendedor vendedor2 : contactos) {
			ListaEnlazada<Producto> temporal = vendedor2.obtenerProductos();
			for (Producto producto : temporal) {
				ordenProductos.agregarBinarioOrdenado(producto);
			}
		}
		ordenProductos.inOrden(listaGnralPdctos);

		return listaGnralPdctos;
	}

//	 - obtenerListaProductosVendedorPorFecha	
	/*
	 * Método que permite obtener la lista de productos del vendedor publicados
	 * mostrándolo desde el más reciente hasta el más antiguo
	 * 
	 * @Param vendedor
	 */

	public ListaEnlazada<Producto> obtenerListaProductosVendedorPorFecha(String vendedor) throws ErrorNodoNoExiste {

		ListaEnlazada<Producto> productos = vendedores.getDato(vendedor).obtenerProductos();

		Producto arreglo[] = new Producto[productos.getLongitud()];
		int i = 0;
		for (Producto producto : productos) {

			arreglo[i] = producto;
			i++;

		}

		// ordena por fecha actual a mas vieja
		for (i = 0; i < arreglo.length - 1; i++) {
			for (int j = i + 1; j < arreglo.length; j++) {
				// El compareTo retorna un 0 sin son iguales, < 0 si es alfabeticamente menor y
				// > 0 si es alfabeticamente mayor
				if (arreglo[i].getFechaPublicacion().compareTo(arreglo[j].getFechaPublicacion()) < 0) {
					Producto aux = arreglo[i];
					arreglo[i] = arreglo[j];
					arreglo[j] = aux;
				}
			}
		}

		productos.vaciarLista();

		for (i = 0; i < arreglo.length; i++) {
			productos.agregarFinal(arreglo[i]);
		}

		return productos;

	}

//	 - obtenerCantidadPdctosPublicadosVendedor
	/*
	 * Método que obtiene la cantidad de productor publicados por el vendedor
	 * 
	 * @Param Vendedor
	 */

	public int obtenerCantidadPdctosPublicadosVendedor(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		int cantidad = vendedores.getDato(vendedor).obtenerProductos().getLongitud();
		return cantidad;
	}

//	 - obtenerCantidadContactosVendedor	
	/*
	 * Metodo que obtiene la cantidad de contactor que tiene un vendedor
	 * 
	 * @Param vendedor
	 */

	public int obtenerCantidadContactosVendedor(String vendedor)
			throws ErrorNodoNoExiste, ErrorNodosConectados, ErrorExisteNodo {

		int cantidad = obtenerListaContactos(vendedor).getLongitud();
		return cantidad;
	}

	public ListaEnlazada<Vendedor> obtenerListaVendedores() {
		return vendedores.getDatos();
	}

	public Chat obtenerChat(String vendedor, String contacto) throws ErrorNodoNoExiste {
		return vendedores.getDato(vendedor).obtenerChat(contacto);
	}

	/*
	 * Método que obtinene la cantidad de publicaciones que hay entre unas fechas
	 * dadas
	 * 
	 * @Param fecha1 y fecha2
	 */
	public int obtenerCantidadPublicacionesEntreFechas(String fecha1, String fecha2) {

		ListaEnlazada<Vendedor> listaTodosLosVendedores = vendedores.getDatos();
		ListaEnlazada<Producto> productosGenerales = new ListaEnlazada<Producto>();

		for (Vendedor vendedor : listaTodosLosVendedores) {
			ListaEnlazada<Producto> productos = vendedor.obtenerProductos();
			for (Producto producto1 : productos) {

				if (producto1.getFechaPublicacion().compareTo(fecha1) >= 0
						&& producto1.getFechaPublicacion().compareTo(fecha2) <= 0)
					productosGenerales.agregarFinal(producto1);
			}

		}

		return productosGenerales.getLongitud();
	}
}

