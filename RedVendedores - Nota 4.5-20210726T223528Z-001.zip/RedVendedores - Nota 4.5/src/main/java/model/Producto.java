package model;

import java.util.HashMap;

import estructuras.ListaEnlazada;

public class Producto implements Comparable<Producto> {

	private String categoria;
	private String nombre;
	private String fechaPublicacion;
	private Vendedor vendedor;
	private ListaEnlazada<Comentario> comentarios;
	private HashMap<String,MeGusta> meGustas;

	/*
	 * Constructor de la clase Producto
	 * 
	 * @Param categoria, nombre, fechaPublicación y vendedor
	 */
	public Producto(String categoria, String nombre, String fechaPublicacion, Vendedor vendedor) {
		super();
		this.categoria = categoria;
		this.nombre = nombre;
		this.fechaPublicacion = fechaPublicacion;
		this.vendedor = vendedor;
		comentarios = new ListaEnlazada<Comentario>();
		meGustas = new HashMap<String, MeGusta>();
	}

	/*
	 * Método que obtiene la cantidad de MeGustas
	 */
	public int obtenerCantidadMeGustas() {
		return meGustas.size();
	}

	/*
	 * Método que adiciona comentarios que hagan sobre el producto en una lista
	 */
	public void adicionarComentario(Comentario comentario) {
		comentarios.agregar(comentario);
	}

	/*
	 * Método que adiciona MeGustas de un producto en una lista
	 */
	public int adicionarMeGusta(MeGusta meGusta) {
		String auxiliar = meGusta.getVendedor().getNombre();
		if( meGustas.get(auxiliar) != null ) {
			meGustas.remove(auxiliar);
			return -1;
		}else {
			meGustas.put(auxiliar,meGusta);
			return 1;
		}
	}

	/*
	 * Métodos get y set de la clase producto
	 */
	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFechaPublicacion() {
		return fechaPublicacion;
	}

	public void setFechaPublicacion(String fechaPublicacion) {
		this.fechaPublicacion = fechaPublicacion;
	}

	public ListaEnlazada<Comentario> getComentarios() {
		return comentarios;
	}

	public ListaEnlazada<MeGusta> getMeGustas() {
		ListaEnlazada<MeGusta> listaMegustas = new ListaEnlazada<MeGusta>();
		for (MeGusta meGusta : meGustas.values()) {
			listaMegustas.agregarFinal(meGusta);
		}
		return listaMegustas;
	}

	public Vendedor getVendedor() {
		return vendedor;
	}

	public void setVendedor(Vendedor vendedor) {
		this.vendedor = vendedor;
	}

	/*
	 * Metodo toString Metodo que imprime el producto con sus parametros
	 * concatenados
	 */
	@Override
	public String toString() {
		return "Producto [categoria=" + categoria + ", nombre=" + nombre + ", fechaPublicacion=" + fechaPublicacion
				+ "]";
	}

	@Override
	public int compareTo(Producto o) {
		return categoria.concat(nombre).compareTo(o.categoria.concat(o.nombre));
	}

}
