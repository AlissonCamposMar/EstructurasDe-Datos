package model;

import estructuras.ListaEnlazada;

	//Sandra eres la mejor nunca cambies no sé por que no te aparece esa mondá comentada voy a shorar
	//la vida es cruel
	//Sandris estoy en la guerra de vietnam
public class Chat {
	private Vendedor vendedor1;
	private Vendedor vendedor2;

	private ListaEnlazada<Mensaje> mensajes;

	/*
	 * Constructor para la clase Chat
	 * 
	 * @Param vendedor1 y vendedor 2
	 */
	public Chat(Vendedor vendedor1, Vendedor vendedor2) {
		this.vendedor1 = vendedor1;
		this.vendedor2 = vendedor2;
		mensajes = new ListaEnlazada<Mensaje>();
	}

	/*
	 * Métodos get y set de la clase Chat
	 */

	public Vendedor getVendedor1() {
		return vendedor1;
	}

	public Vendedor getVendedor2() {
		return vendedor2;
	}

	/*
	 * Lista que contiene los mensajes entre los dos vendedores
	 */
	public ListaEnlazada<Mensaje> getMensajes() {
		return mensajes;
	}

	/*
	 * Método que agrega los mensajes al final de la lista
	 */
	public void adicionarMensaje(Mensaje mensaje) {
		mensajes.agregarFinal(mensaje);
	}

}
