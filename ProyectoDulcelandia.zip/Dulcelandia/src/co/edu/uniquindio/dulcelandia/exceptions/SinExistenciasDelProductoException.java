package co.edu.uniquindio.dulcelandia.exceptions;

public class SinExistenciasDelProductoException extends Exception {
	/**
	 * Constructor de la clase
	 * @param mensaje El mensaje mostrado
	 */
		public SinExistenciasDelProductoException(String mensaje) {
			super(mensaje);
			// TODO Auto-generated constructor stub
		}
}
