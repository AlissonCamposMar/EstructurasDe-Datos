package co.edu.uniquindio.dulcelandia.exceptions;

public class ActualizarClienteException extends Exception{
	private static final long serialVersionUID = 1L;
	public ActualizarClienteException(String mensaje){
		super(mensaje);
		}
}

