package co.edu.uniquindio.dulcelandia.services;

public interface IModelFactoryService {
	public void inicializarDatos ();

}
