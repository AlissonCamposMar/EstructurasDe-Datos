package co.edu.uniquindio.dulcelandia.exceptions;

public class ActualizarProveedorException extends Exception {
	private static final long serialVersionUID = 1L;
	public ActualizarProveedorException(String mensaje){
		super(mensaje);
		}
}
