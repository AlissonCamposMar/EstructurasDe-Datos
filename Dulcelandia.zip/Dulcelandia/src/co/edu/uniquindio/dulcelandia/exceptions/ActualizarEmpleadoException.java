package co.edu.uniquindio.dulcelandia.exceptions;

public class ActualizarEmpleadoException extends Exception{
	private static final long serialVersionUID = 1L;
	public ActualizarEmpleadoException(String mensaje){
		super(mensaje);
		}
}


