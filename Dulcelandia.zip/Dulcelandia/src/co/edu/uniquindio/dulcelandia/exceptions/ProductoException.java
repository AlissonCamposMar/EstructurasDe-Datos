
package co.edu.uniquindio.dulcelandia.exceptions;

public class ProductoException extends Exception {
	private static final long serialVersionUID = 1L;
	public ProductoException(String mensaje){
		super(mensaje);
		}
}
