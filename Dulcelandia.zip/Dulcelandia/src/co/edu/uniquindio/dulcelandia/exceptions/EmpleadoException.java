package co.edu.uniquindio.dulcelandia.exceptions;

public class EmpleadoException extends Exception {
	private static final long serialVersionUID = 1L;
	
	public EmpleadoException(String mensaje){
		super(mensaje);
		}
}
