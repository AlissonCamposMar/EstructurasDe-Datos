package co.edu.uniquindio.dulcelandia.exceptions;

public class ActualizarVentaException extends Exception {
	private static final long serialVersionUID = 1L;
	public ActualizarVentaException(String mensaje){
		super(mensaje);
	}
}