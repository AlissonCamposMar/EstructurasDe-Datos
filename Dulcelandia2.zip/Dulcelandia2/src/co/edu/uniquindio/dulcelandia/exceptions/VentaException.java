package co.edu.uniquindio.dulcelandia.exceptions;

public class VentaException extends Exception{

		/**
		 *
		 */
		private static final long serialVersionUID = 1L;

		public VentaException(String mensaje){
			super(mensaje);
		}
	}
