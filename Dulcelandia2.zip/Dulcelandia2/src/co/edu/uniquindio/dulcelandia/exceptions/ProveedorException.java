package co.edu.uniquindio.dulcelandia.exceptions;

public class ProveedorException extends Exception{
	private static final long serialVersionUID = 1L;
	public ProveedorException(String mensaje){
		super(mensaje);
		}
}
