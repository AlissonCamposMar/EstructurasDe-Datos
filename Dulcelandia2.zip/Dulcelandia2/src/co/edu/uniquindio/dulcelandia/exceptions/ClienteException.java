package co.edu.uniquindio.dulcelandia.exceptions;

public class ClienteException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public ClienteException(String mensaje){
		super(mensaje);
	}
}
