package co.edu.uniquindio.dulcelandia.services;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface IModelFactoryService {
	public void inicializarDatos () throws FileNotFoundException, IOException;

}
